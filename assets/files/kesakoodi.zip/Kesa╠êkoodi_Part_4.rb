# Kesäkoodi-biisi 2016 / MEHACKIT & CREW / SuomiAreena 2016 / Made with Sonic Pi <3
# PART IV

samplet = "/home/codemonkey/kesakoodi/samplet"

use_bpm 124

# VERSE C + OUTRO
# FEAT. CHORDS & BEATS BY TELMA PEURA & JANITA FLINKMAN 
# & ARI HAMARA (SUPERSONIC DRAGONFLY) & KAISA KUKKONEN

# Telman kesäiset biitit

in_thread do
  16.times do
    sample :drum_bass_soft, amp: 2
    sleep 1
    sample :drum_snare_hard, amp: 0.5
    sleep 1
    sample :drum_bass_soft, amp: 2
    sleep 1
    sample :drum_snare_hard, amp: 0.5
    sleep 1
  end
end

in_thread do
  16.times do
    sample :drum_cymbal_closed
    sleep 0.75
    sample :drum_cymbal_pedal
    sleep 2.25
  end
end

in_thread do
  with_fx :reverb do
    with_fx :echo, phase: 0.5, decay: 8 do
      8.times do
        use_synth :beep
        1.times do play_chord chord(:C, :major) end
        play :C2, release: 4
        sleep 4
        1.times do play_chord chord(:A, :minor) end
        play :A1, release: 4
        sleep 4
        1.times do play_chord chord(:F, :major)  end
        play :F1, release: 4
        sleep 4
        1.times do play_chord chord(:G, :major)  end
        play :G1, release: 4
        sleep 4
      end
    end
  end
end

in_thread do
  with_fx :rlpf, cutoff: 60, res: 0.75, cutoff_slide: 8 do |lpf|
    filter_values = [60, 60, 70, 80, 90, 100, 110, 120, 100, 90, 80, 70].ring
    8.times do
      control lpf, cutoff: filter_values.tick
      sample samplet, "synth_bright_cmaj", amp: 2
      sleep 4
      control lpf, cutoff: filter_values.tick
      sample samplet, "synth_bright_amin", amp: 2
      sleep 4
      control lpf, cutoff: filter_values.tick
      sample samplet, "synth_bright_fmaj", amp: 2
      sleep 4
      sample samplet, "synth_bright_gmaj", amp: 2
      sleep 4
    end
  end
end

in_thread delay: 16 do
  with_fx :rhpf, cutoff: 110, cutoff_slide: 4, res: 0.6 do |hpf|
    filter_values = [100, 80, 70, 60, 70, 80, 90, 100, 90, 80, 70, 90].ring
    8.times do
      control hpf, cutoff: filter_values.tick
      sample samplet, "synth_bright_arp", amp: 2
      sleep 4
    end
  end
end

with_fx :reverb, mix: 0.1 do
  in_thread do
    use_synth :beep
    3.times do
      play_pattern_timed [:g4,:f4,:e4,:d4,:c4,:c4,:a3,:g3,:c4], [0.5,0.5,0.5,0.5,1,1.5,0.75,0.75,1]
      sleep 9
    end
    play_pattern_timed [:c4,:g3,:a3,:c4,:c4,:d4,:e4,:f4,:g4], [0.5,0.5,0.5,0.5,1,1.5,0.75,0.75,1]
    sleep 9
  end
  in_thread do
    20.times do
      use_synth (ring :tb303, :blade, :prophet, :saw, :beep, :tri).tick
      play :e2, attack: 0, release: 0.5, cutoff: 100, amp: 0.75
      sleep 0.5
      play :g2, attack: 0, release: 0.5, cutoff: 100, amp: 0.75
      sleep 2.5
    end
  end
  in_thread do
    6.times do
      sample samplet, "loop_6"
      sleep 12
    end
  end
end

# Janitan fillaribiitti

in_thread delay: 16 do
  use_transpose 12
  with_fx :hpf, cutoff: 110 do
    4.times do
      sleep 12
      play_pattern_timed [:c4, :d4, :e4, :d4], [0.5, 0.25, 0.75, 0.5]
      sleep 2
    end
  end
end

in_thread delay: 16 do
  2.times do
    3.times do
      2.times do
        sample :elec_twip
        sleep 1
      end
      3.times do
        sample :perc_bell, amp: 0.55
        sleep 1
      end
      2.times do
        sample :elec_twip
        sleep 1
      end
    end
    sleep 3
  end
end

# Ari's Acid Bassline Chord Arpeggio

in_thread do
  with_fx :reverb, room: 0.4, mix: 0.3, amp: 0.4, amp_slide: 16 do |a|
    control a, amp: 1.3
    use_synth :tb303
    use_random_seed 121
    use_synth_defaults attack: 0, release: 0.15, amp: 0.9, res: 0.4
    4.times do |i|
      16.times do |j|
        play chord(:C, :major, num_octaves: 2).ring.tick, cutoff: rrand_i(50, 90) + i * 10, pan: rrand(-0.35, 0.35)
        sleep 0.25
      end
      use_random_seed 423
      16.times do |j|
        play chord(:A, :minor, num_octaves: 2).ring.tick, cutoff: rrand_i(50, 90) + i * 10, pan: rrand(-0.35, 0.35)
        sleep 0.25
      end
      use_random_seed 121
      16.times do |j|
        play chord(:F, :major, num_octaves: 2).ring.tick, cutoff: rrand_i(50, 90) + i * 10, pan: rrand(-0.35, 0.35)
        sleep 0.25
      end
      use_random_seed 423
      16.times do |j|
        play chord(:G, :major, num_octaves: 2).ring.tick, cutoff: rrand_i(50, 90) + i * 10, pan: rrand(-0.35, 0.35)
        sleep 0.25
      end
    end
  end
end

# Kesäkoodi-biisi 2016
# PART V - OUTRO (AALTOJA)
# BY KAISA KUKKONEN

sleep 64

# Ocean waves
with_fx :reverb, mix: 0.5 do
  in_thread do
    44.times do
      s = synth [:bnoise, :cnoise, :gnoise].choose, amp: rrand(0.4, 1.1), attack: rrand(0, 4), sustain: rrand(0, 2), release: rrand(1, 5), cutoff_slide: rrand(0, 5), cutoff: rrand(60, 100), pan: rrand(-1, 1), pan_slide: rrand(1, 5), amp: rrand(0.5, 1)
      control s, pan: rrand(-1, 1), cutoff: rrand(60, 110)
      sleep rrand(1, 2)
    end
  end
end

sleep 16

in_thread delay: 16 do
  64.times do
    with_fx :flanger, mix: 0 do
      sample :perc_snap, amp: rrand(0.9, 1.4), rate: rrand(1.9, 2.1), cutoff: rrand(80, 120), pan: rrand(-0.25, 0.25)
    end
    sleep 0.25
  end
end

with_fx :reverb, mix: 0.4 do
  with_fx :echo, mix: 0.7 do
    sample :ambi_swoosh, amp: 2
  end
end

in_thread do
  use_synth :prophet
  use_synth_defaults cutoff: rrand(60, 80), release: rrand(1, 4), amp: 1
  with_fx :panslicer, mix: 0.5 do
    with_fx :hpf, cutoff: 70 do
      with_fx :reverb, mix: 0.4 do
        with_fx :echo, mix: 0.2 do
          16.times do
            chord_list = [chord(:C, :major), chord(:A, :minor), chord(:F, :major), chord(:G, :major)].ring
            chord_list.tick
            2.times do
              use_transpose 0
              play_chord chord_list.look
              sleep 0.75
            end
            sleep 0.5
            use_transpose 0
            play_chord chord_list.look, attack: 2, release: 1
            sleep 2
          end
        end
      end
    end
  end
end

# Mehackit haluaa kiittää kaikkia #kesäkoodi-kampanjaan osallistuneita <3
# Jos Sonic Pi:n opiskelu kiinnostaa, niin tutustu ihmeessä Mehackitin materiaaleihin: sonic-pi.mehackit.org