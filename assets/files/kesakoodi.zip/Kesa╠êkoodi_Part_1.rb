# Kesäkoodi-biisi 2016 / MEHACKIT & CREW / SuomiAreena 2016 / Made with Sonic Pi <3
# PART I

# Huom1. Biisi on neljässä osassa, jotka pitää ajaa peräjälkeen. Jokainen osa on hyvä ladata erilliseen buffer-välilehteen!
# Huom2. Muistathan päivittää jokaiseen bufferiin alla olevaan samplet-parametriin oikean hakemistopolun sampleille!
# Lisätietoa samplejen käytöstä löydät täältä: 
# http://sonic-pi.mehackit.org/exercises/fi/05-advanced-topics-1/04-external-samples.html

samplet = "/home/codemonkey/kesakoodi/samplet"

use_bpm 124

# INTRO PART
# FEAT. BEATS BY MC ELOHOLMA & HANNA PÖRHÖ (MEHILÄISBIISI) & JUUSO HEIKKINEN

in_thread do
  8.times do
    sample samplet, "house_3", amp: 1.5, beat_stretch: 8, finish: 0.5
    at [1,3] do sample :sn_dolf end
    at [3] do sample :elec_blup, amp: 0.75, rate: 1 end
    at [0, 1, 1.5, 2.5, 3.5] do sample :drum_snare_soft, amp: 1.25 end
    sleep 4
  end
end

in_thread delay: 16 do
  4.times do
    at [0,1,2,3] do sample :bd_haus end
    sleep 4
  end
end

in_thread do
  4.times do
    with_fx :hpf, cutoff: 80 do
      3.times do
        sample :elec_cymbal, cutoff: range(80, 120, 5).mirror.tick
        8.times do
          sample :drum_cymbal_closed, amp: [0.8, 0.5, 0.65].ring.tick, finish: 0.3, pan: rrand(-0.35, 0.35)
          sleep 0.25
        end
      end
      sample :elec_cymbal, cutoff: 110
      sleep 0.5
      sample :elec_cymbal, cutoff: 100
      sleep 1
      sample :elec_cymbal, cutoff: 110
      sleep 0.25
    end
    sample samplet, "hey_3_fx.wav", amp: 1.75
    sleep 0.25
  end
end

with_fx :reverb do
  in_thread do
    with_fx :lpf, cutoff: 70, cutoff_slide: 2 do |c|
      8.times do
        control c, cutoff: 130
        use_synth :prophet
        use_transpose 12
        notes = [:C3, :D4, :E3, :D4, :C4, :C4, :G3, :C4, :G4]
        sleeptimes = [0.25, 0.25, 0.125, 0.125, 0.25, 0.25, 0.25, 0.25, 0.25]
        play_pattern_timed notes, sleeptimes, pan: rrand(-1,1), release: range(0.15, 0.55, 0.1).tick, amp: 0.9
        control c, cutoff: 70
        play_pattern_timed notes, sleeptimes, pan: rrand(-1,1), release: range(0.15, 0.55, 0.1).tick, amp: 0.9
      end
    end
  end
  
  in_thread do
    8.times do
      use_transpose 0
      use_transpose 12 if one_in(4)
      play_pattern_timed [:c4,:e4, :e4, :e4, :e4], [ 0.25, 0.25, 0.25, 0.25], attack: 0, release: 0.2
      sleep 2.75
    end
  end
end

in_thread do
  sleep 24
  sample samplet, "music_loop_1", amp: 4, rate: -1, attack: 4
  sleep 4
  sample samplet, "vox_fx_1", amp: 3
end

in_thread do
  sleep 16
  with_fx :rlpf, cutoff: 40, res: 0.7, cutoff_slide: 16 do |fx|
    control fx, cutoff: 80
    4.times do
      sample samplet, "synth_amin7", amp: 2
      sleep 4
    end
  end
end

# Ukko Noa by Juuso Heikkinen

in_thread delay: 24 do
  with_fx :reverb, amp: 0.1, amp_slide: 8 do |c|
    control c, amp: 1.0
    use_synth_defaults release: 0.1
    use_transpose 12
    play 84
    sleep 0.5
    play 84
    sleep 0.5
    play 84
    sleep 0.5
    play 88
    sleep 0.5
    play 86
    sleep 0.5
    play 86
    sleep 0.5
    play 86
    sleep 0.5
    play 89
    sleep 0.5
    play 88
    sleep 0.5
    play 88
    sleep 0.5
    play 86
    sleep 0.5
    play 86
    sleep 0.5
    play 84
    sleep 2.0
    
  end
end

in_thread delay: 24 do
  with_fx :rhpf, cutoff: 130, res: 0.6, cutoff_slide: 8 do |hpf|
    control hpf, cutoff: 40
    8.times do
      4.times do
        sample :drum_heavy_kick
        sleep 0.125
      end
      sample :drum_snare_hard
      4.times do
        sample :drum_heavy_kick
        sleep 0.125
      end
    end
  end
end
