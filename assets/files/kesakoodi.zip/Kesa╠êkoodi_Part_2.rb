# Kesäkoodi-biisi 2016 / MEHACKIT & CREW / SuomiAreena 2016 / Made with Sonic Pi <3
# PART II

samplet = "/home/codemonkey/kesakoodi/samplet"

use_bpm 124

# VERSE A
# FEAT. BEATS BY HELMI HÄRKÖNEN & MC MADMAN & JUUSO HEIKKINEN

# Helmin rummut

in_thread do
  4.times do
    at [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15] do sample :bd_haus, cutoff: 70, amp: 1.5 end
    at [0, 2, 2.75, 3.5, 4, 6, 6.75, 7.5, 8, 10, 10.75, 11.5, 12, 14, 14.75, 15.5] do sample :sn_dolf end
    at [0, 2, 2.75, 3.5, 4, 6, 6.75, 7.5] do sample samplet, "hey_3_fx", amp: 2.5 end
    64.times do
      sample :drum_cymbal_closed, amp: [0.8, 0.5, 0.65].ring.tick, finish: 0.3, pan: rrand(-0.35, 0.35)
      sleep 0.25
    end
  end
end

# Helmin melodia

with_fx :reverb, mix: 0.3 do
  with_fx :hpf, cutoff: 60 do
    in_thread do
      with_fx :rlpf, res: 0.8, cutoff: 70, cutoff_slide: 8 do |c|
        8.times do
          control c, cutoff: 130
          use_synth :chipbass
          use_synth_defaults release: 0.25
          use_transpose 0
          play :C4, pan: rrand(-0.5, 0.5)
          sleep 0.5
          play_pattern_timed [:G4, :E4, :D4, :C4], [0.5, 0.25, 0.25, 0.5], pan: rrand(-0.5, 0.5)
          play :C4, pan: rrand(-0.5, 0.5)
          play :F4, pan: rrand(-0.5, 0.5)
          sleep 0.5
          play [:C4, :A4], pan: rrand(-0.5, 0.5)
          sleep 0.5
          play [:C4, :E4, :G4], pan: rrand(-0.5, 0.5)
          sleep 1
          5.times do
            play [:F4, :A4], pan: rrand(-0.5, 0.5)
            sleep 0.5
          end
          play_pattern_timed [:F4, :A4, :E4, :G4], [0, 0.5, 0, 1.0], pan: rrand(-0.5, 0.5)
        end
      end
    end
  end
  
  # Soinnut
  
  with_fx :hpf, cutoff: 50 do
    in_thread do
      
      use_transpose 12
      use_synth :beep
      use_synth_defaults amp: 1.5
      2.times do
        play [:A2, :C3, :E3, :G3], attack: 1, release: 4
        sleep 4
        
        play [:E2, :G2, :B2, :D3], attack: 1, release: 4
        sleep 4
        
        play [:C2, :E2, :G2, :C3], attack: 1, release: 8
        sleep 8
        
        play [:A2, :C3, :E3, :G3], attack: 1, release: 4
        sleep 4
        
        play [:E2, :G2, :B2], attack: 1, release: 4
        sleep 4
        
        play [:F2, :A2, :C3, :E3], attack: 1, release: 8
        sleep 8
      end
    end
    
    with_fx :panslicer, mix: 0.2 do
      in_thread do
        
        use_transpose 12
        use_synth :saw
        use_synth_defaults amp: 1.1, cutoff: 80
        
        2.times do
          play [:A2, :C3, :E3, :G3], attack: 1, release: 4
          sleep 4
          
          play [:E2, :G2, :B2, :D3], attack: 1, release: 4
          sleep 4
          
          play [:C2, :E2, :G2, :C3], attack: 1, release: 8
          sleep 8
          
          play [:A2, :C3, :E3, :G3], attack: 1, release: 4
          sleep 4
          
          play [:E2, :G2, :B2], attack: 1, release: 4
          sleep 4
          
          play [:F2, :A2, :C3, :E3], attack: 1, release: 8
          sleep 8
        end
      end
    end
    
    # Lisämelodia
    
    with_fx :reverb, mix: 0.3, room: 0.7, amp: 2 do
      with_fx :hpf, cutoff: 100 do
        in_thread do
          use_transpose 12
          use_synth :mod_tri
          use_synth_defaults mod_range: 12, mod_wave: 1, mod_invert_wave: 1, mod_phase: 0.5, mod_pulse_width: 0.5, attack: rrand(0.1, 0.4), release: 0.1
          
          4.times do
            play :C4, pan: rrand(-0.5, 0.5)
            sleep 2
            play :G4, pan: rrand(-0.5, 0.5)
            sleep 0.85
            play :B4, pan: rrand(-0.5, 0.5)
            sleep 0.85
            play :C5, pan: rrand(-0.5, 0.5)
            sleep 1.3
            play :C4, pan: rrand(-0.5, 0.5)
            sleep 1
            play :G4, pan: rrand(-0.5, 0.5)
            sleep 1
            play :B4, pan: rrand(-0.5, 0.5)
            sleep 1
            play :G4, pan: rrand(-0.5, 0.5)
            sleep 8
          end
        end
      end
    end
  end
  
  # Bassolinja
  
  in_thread do
    2.times do
      use_synth :sine
      play :A1, release: 4
      sleep 4
      
      play :E1, release: 4
      sleep 4
      
      play :C1, release: 8
      sleep 8
      
      play :A1, release: 4
      sleep 4
      
      play :E1, release: 4
      sleep 4
      
      play :F1, release: 8
      sleep 8
    end
    play :A1, release: 4
    sleep 4
    
    play :C2, release: 4
    sleep 4
    
    play :F1, release: 4
    sleep 4
    
    play :A1, release: 4
    sleep 4
    
    play :C2, release: 4
    sleep 4
    
    play :A1, release: 4
    sleep 4
    
    play :G1, release: 4
    sleep 4
    
    play :E1, release: 4
    sleep 4
    
  end
  
  # Vilma Alinan laulusample
  
  with_fx :distortion, mix: 0.3 do
    in_thread delay: 32 do
      with_fx :rlpf, res: 0.7, cutoff: 60, cutoff_slide: 8 do |c|
        2.times do
          control c, cutoff: [130,60].ring.tick
          sample samplet, "loop_6_fx", beat_stretch: 8
          sleep 8
        end
      end
    end
  end
end

# Ukko Noa, pt. II by Juuso Heikkinen

in_thread do
  with_fx :reverb, amp: 1.0, amp_slide: 20 do |c|
    
    use_synth_defaults release: 0.1
    use_transpose 12
    
    2.times do
      
      play 88, amp: 0.4
      sleep 0.5
      play 88, amp: 0.5
      sleep 0.5
      play 88, amp: 0.75
      sleep 0.5
      play 88
      sleep 0.5
      play 91
      sleep 1
      play 89
      sleep 1
      play 86, amp: 0.5
      sleep 0.5
      play 86, amp: 0.6
      sleep 0.5
      play 86, amp: 0.75
      sleep 0.5
      play 86
      sleep 0.5
      play 89
      sleep 1
      play 88
      sleep 1
      
      play [84, 84-12]
      sleep 0.5
      play [84, 84-12]
      sleep 0.5
      play [84, 84-12]
      sleep 0.5
      play [88, 88-12]
      sleep 0.5
      play [86, 86-12]
      sleep 0.5
      play [86, 86-12]
      sleep 0.5
      play [86, 86-12]
      sleep 0.5
      play [89, 89-12]
      sleep 0.5
      play [88, 88-12]
      sleep 0.5
      play [88, 88-12]
      sleep 0.5
      play [86, 86-12]
      sleep 0.5
      play [86, 86-12]
      sleep 0.5
      play [84, 84-12]
      control c, amp: 0
      sleep 2.0
    end
  end
end

in_thread do
  3.times do
    sample samplet, "vox_fx_2", amp: 2
    sleep 16
    sample samplet, "vox_fx_2", amp: 2
    sleep 14
    sample samplet, "vox_fx_3", amp: 3
    sleep 2
  end
end

# Sämplätyt syntikat filtteri-efektin läpi

in_thread do
  with_fx :rlpf, res: 0.6, cutoff: 70, cutoff_slide: 4 do |c|
    cutoff_controls = [90, 120, 100, 70].ring
    2.times do
      sample samplet, "synth_amin7", amp: 2
      sleep 4
      control c, cutoff: cutoff_controls.tick
      
      sample samplet, "synth_emin7", amp: 2
      sleep 4
      control c, cutoff: cutoff_controls.tick
      
      sample samplet, "synth_cmaj_oct", amp: 2
      sleep 8
      control c, cutoff: cutoff_controls.tick
      
      sample samplet, "synth_amin7", amp: 2
      sleep 4
      control c, cutoff: cutoff_controls.tick
      
      sample samplet, "synth_emin", amp: 2
      sleep 4
      control c, cutoff: cutoff_controls.tick
      
      sample samplet, "synth_fmaj7", amp: 2
      sleep 8
      control c, cutoff: cutoff_controls.tick
      cutoff_controls = [130, 120].ring
    end
    control c, cutoff: 80
    sample samplet, "synth_bridge_1", amp: 2, finish: 0.5
    sleep 4
    
    control c, cutoff: 90
    sample samplet, "synth_bridge_2", amp: 2, finish: 0.5
    sleep 4
    
    control c, cutoff: 100
    sample samplet, "synth_bridge_3", amp: 2, finish: 0.5
    sleep 4
    
    control c, cutoff: 110
    sample samplet, "synth_bridge_4", amp: 2, finish: 0.5
    sleep 4
    
    control c, cutoff: 130
    sample samplet, "synth_bridge_5", amp: 2, finish: 0.5
    sleep 4
    
    control c, cutoff: 95
    sample samplet, "synth_bridge_6", amp: 2, finish: 0.5
    sleep 4
    
    control c, cutoff: 75
    sample samplet, "synth_bridge_7", amp: 2, finish: 0.5
    sleep 4
    
    control c, cutoff: 50
    sample samplet, "synth_bridge_8", amp: 2, finish: 0.5
    sleep 4
  end
end

# Seuraavan osion rummut feidaavat sisään (Rummut by VILMA ALINA)

in_thread do
  sleep 64
  with_fx :hpf, cutoff: 130, cutoff_slide: 32 do |h|
    control h, cutoff: 75
    4.times do
      at [0,1,2,3,4,5,6,7] do sample :bd_haus, cutoff: range(70, 110, 1).mirror.tick end
      at [7] do sample :perc_till, start: 0.15, rate: pitch_to_ratio(0) end
      at [1,3,5,7] do
        sample :perc_snap, amp: 0.8
        sample :perc_snap2,amp: 0.5
      end
      sleep 8
    end
  end
end
