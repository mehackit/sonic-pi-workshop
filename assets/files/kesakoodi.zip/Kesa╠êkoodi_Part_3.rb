# Kesäkoodi-biisi 2016 / MEHACKIT & CREW / SuomiAreena 2016 / Made with Sonic Pi <3
# PART III

samplet = "/home/codemonkey/kesakoodi/samplet"

use_bpm 124

# VERSE B
# FEAT. BEATS BY VILMA ALINA & ARI HAMARA (SUPERSONIC DRAGONFLY)
# & ANNIE TALVISTO & ALISSA KAARAKAINEN

# Vilma Alinan rummut

in_thread do
  10.times do
    at [0,1,2,3,4,5,6,7] do sample :bd_haus, amp: 1.5, cutoff: range(70, 110, 1).mirror.tick end
    at [7] do sample :perc_till, start: 0.15, rate: pitch_to_ratio(0) end
    at [1,3,5,7] do
      sample :perc_snap, amp: 0.8
      sample :perc_snap2,amp: 0.5
    end
    32.times do
      sample :drum_cymbal_closed, cutoff: range(70, 100, 0.5).mirror.tick
      sleep 0.25
    end
  end
end

in_thread delay: 14 do
  sample samplet, "vox_fx_3", amp: 2
  sleep 2
  with_fx :rhpf, cutoff: 110, cutoff_slide: 32, res: 0.5 do |hf|
    control hf, cutoff: 40
    4.times do
      with_fx :hpf, cutoff: 90 do
        sample samplet, "kesakoodi_1", rate: 1.00, amp: 3, pan: -1
        sample samplet, "kesakoodi_1", rate: 0.97, amp: 3, pan: 1
      end
      2.times do
        at [0, 2, 2.75, 3.5, 4, 6, 6.75, 7.5] do
          sample samplet, "hey_2_fx", amp: 2, pan: rrand(-0.75, 0.75)
          sample :sn_dolf, amp: 0.5
        end
        sleep 8
      end
    end
  end
end

# Alissan lisäbiitti

in_thread delay: 16 do
  with_fx :rlpf, cutoff: 60, cutoff_slide: 16 do |i|
    control i, cutoff: 120
    16.times do |j|
      use_sample_defaults hpf: 75
      at [0, 2] do sample :drum_heavy_kick end
      at [1, 3] do sample :drum_snare_hard end
      3.times do
        sample :drum_cymbal_closed
        sleep 0.25
        sample :drum_cymbal_pedal
        sleep 1
      end
      sleep 0.25
      if j == 12
        control i, cutoff: 60
      end
    end
  end
end

# Vilma Alinan soinnut

with_fx :reverb, mix: 0.5, room: 0.5 do
  with_fx :slicer, phase: 0.25, mix: 0.5 do
    in_thread do
      use_synth :sine
      use_synth_defaults attack: 1, release: 3, cutoff: 130
      4.times do
        play (chord :C4, '7sus4')
        sleep 4
        play (chord :A3, :minor7)
        sleep 4
        play (chord :G3, '7sus4')
        sleep 4
        play (chord :A3, :minor), attack: 1, release: 1.5
        sleep 2
        play (chord :A3, :minor7), attack: 0.5, release: 2
        sleep 2
      end
      1.times do
        play (chord :C4, '7sus4')
        sleep 4
        play (chord :A3, :minor7)
        sleep 4
        play (chord :G3, '7sus4')
        sleep 4
        play (chord :G3, '7sus4')
        sleep 4
      end
    end
    
    in_thread do
      use_synth :saw
      use_synth_defaults attack: 1, release: 3, cutoff: 80
      
      4.times do
        play (chord :C4, '7sus4')
        sleep 4
        play (chord :A3, :minor7)
        sleep 4
        play (chord :G3, '7sus4')
        sleep 4
        play (chord :A3, :minor), attack: 1, release: 1.5
        sleep 2
        play (chord :A3, :minor7), attack: 0.5, release: 2
        sleep 2
      end
      1.times do
        play (chord :C4, '7sus4')
        sleep 4
        play (chord :A3, :minor7)
        sleep 4
        play (chord :G3, '7sus4')
        sleep 4
        play (chord :G3, '7sus4')
        sleep 4
      end
    end
  end
end

in_thread do
  with_fx :rlpf, cutoff: 90, cutoff_slide: 8, res: 0.7 do |lf|
    cutoff_values = [100, 110, 120, 110, 100, 90, 80, 90].ring
    4.times do
      control lf, cutoff: cutoff_values.tick
      sample samplet, "synth_c7sus4", amp: 2
      sleep 4
      sample samplet, "synth_amin7_2", amp: 2
      sleep 4
      control lf, cutoff: cutoff_values.tick
      sample samplet, "synth_g7sus4", amp: 2
      sleep 4
      sample samplet, "synth_amin", amp: 2
      sleep 4
    end
    1.times do
      control lf, cutoff: cutoff_values.tick
      sample samplet, "synth_c7sus4", amp: 2
      sleep 4
      sample samplet, "synth_amin7_2", amp: 2
      sleep 4
      control lf, cutoff: cutoff_values.tick
      sample samplet, "synth_g7sus4", amp: 2
      sleep 4
      sample samplet, "synth_g7sus4", amp: 2
      sleep 4
    end
  end
end

# Bassolinja

in_thread do
  4.times do
    use_synth :sine
    play :C2, release: 4
    sleep 4
    
    play :A1, release: 4
    sleep 4
    
    play :G1, release: 4
    sleep 4
    
    play :A1, release: 4
    sleep 4
  end
  1.times do
    use_synth :sine
    play :C2, release: 4
    sleep 4
    
    play :A1, release: 4
    sleep 4
    
    play :G1, release: 8
    sleep 8
  end
end

# Annie Talviston biitti

in_thread delay: 16 do
  with_fx :hpf, cutoff: 90, amp: 0, amp_slide: 32 do |a|
    control a, amp: 1.0
    31.times do
      sleep 1
      sample :drum_snare_hard
      sample :elec_fuzz_tom
      sleep 1
    end
    2.times do
      sample :drum_snare_hard
      sample :elec_fuzz_tom
      sleep 1
    end
  end
end


# Ari's Acid Bassline I


with_fx :hpf, cutoff: 60 do
  in_thread delay: 16 do
    with_fx :reverb, room: 0.4, mix: 0.3, amp: 0.4, amp_slide: 16 do |a|
      control a, amp: 1.3
      use_synth :tb303
      use_random_seed 121
      use_synth_defaults attack: 0, release: 0.2, res: 0.6, amp: 0.9
      4.times do |i|
        16.times do |j|
          play chord(:C4, '7sus4', num_octaves: 2).ring.tick, cutoff: rrand_i(50, 60+(j/8)*10) + i * 10, pan: rrand(-0.35, 0.35)
          sleep 0.25
        end
        use_random_seed 423
        16.times do |j|
          play chord(:A3, :minor7, num_octaves: 2).ring.tick, cutoff: rrand_i(50, 60+(j/8)*10) + i * 10, pan: rrand(-0.35, 0.35)
          sleep 0.25
        end
        use_random_seed 121
        16.times do |j|
          play chord(:G3, '7sus4', num_octaves: 2).ring.tick, cutoff: rrand_i(50, 60+(j/8)*10) + i * 10, pan: rrand(-0.35, 0.35)
          sleep 0.25
        end
        use_random_seed 423
        16.times do |j|
          play chord(:A3, :minor, num_octaves: 2).ring.tick, cutoff: rrand_i(50, 60+(j/8)*10) + i * 10, pan: rrand(-0.35, 0.35)
          sleep 0.25
        end
      end
    end
  end
  
  
  # Vilma Alinan lauluäänestä tehty "arpeggio"
  
  with_fx :reverb, mix: 0.4, room: 0.3, amp: 1 do
    in_thread do
      with_fx :rlpf, cutoff: 130, cutoff_slide: 8, res: 0.7 do |c|
        4.times do
          control c, cutoff: 70
          16.times do
            samplet2 = ["c3_fx", "f3_fx", "g3_fx", "c4_fx"].ring
            sample samplet, samplet2.tick, rate: 1, finish: 0.25, start: 0.2
            sleep 0.25
          end
          16.times do
            samplet2 = ["a2_fx", "c3_fx", "e3_fx", "a3_fx"].ring
            sample samplet, samplet2.tick, rate: 1, finish: 0.25, start: 0.2
            sleep 0.25
          end
          control c, cutoff: 130
          16.times do
            samplet2 = ["g2_fx", "c3_fx", "d3_fx", "f3_fx"].ring
            sample samplet, samplet2.tick, rate: 1, finish: 0.25, start: 0.2
            sleep 0.25
          end
          16.times do
            samplet2 = ["a2_fx", "c3_fx", "e3_fx", "g3_fx"].ring
            sample samplet, samplet2.tick, rate: 1, finish: 0.25, start: 0.2
            sleep 0.25
          end
        end
        1.times do
          control c, cutoff: 70
          16.times do
            samplet2 = ["c3_fx", "f3_fx", "g3_fx", "c4_fx"].ring
            sample samplet, samplet2.tick, rate: 1, finish: 0.25, start: 0.2
            sleep 0.25
          end
          16.times do
            samplet2 = ["a2_fx", "c3_fx", "e3_fx", "a3_fx"].ring
            sample samplet, samplet2.tick, rate: 1, finish: 0.25, start: 0.2
            sleep 0.25
          end
          control c, cutoff: 130
          32.times do
            samplet2 = ["g2_fx", "c3_fx", "d3_fx", "f3_fx"].ring
            sample samplet, samplet2.tick, rate: 1, finish: 0.25, start: 0.2
            sleep 0.25
          end
        end
      end
    end
    
    in_thread delay: 16 do
      with_fx :lpf, cutoff: 20, cutoff_slide: 16 do |vox|
        control vox, cutoff: 130
        4.times do
          sample samplet, "loop_3_fx", amp: 3
          sleep 16
        end
      end
    end
  end
end
